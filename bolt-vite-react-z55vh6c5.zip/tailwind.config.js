/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        sage: {
          50: '#f4f7f4',
          100: '#e6ede6',
          200: '#cfdccf',
          300: '#adc2ad',
          400: '#85a185',
          500: '#658465',
          600: '#526952',
          700: '#435543',
          800: '#394539',
          900: '#313b31',
        },
      },
      typography: {
        DEFAULT: {
          css: {
            color: '#526952',
            a: {
              color: '#526952',
              '&:hover': {
                color: '#435543',
              },
            },
            strong: {
              color: '#394539',
            },
            h1: {
              color: '#394539',
            },
            h2: {
              color: '#394539',
            },
            h3: {
              color: '#394539',
            },
            h4: {
              color: '#394539',
            },
            code: {
              color: '#394539',
            },
            blockquote: {
              color: '#526952',
              borderLeftColor: '#cfdccf',
            },
            'ul > li::marker': {
              color: '#85a185',
            },
          },
        },
      },
    },
  },
  plugins: [
    require('@tailwindcss/typography'),
  ],
}