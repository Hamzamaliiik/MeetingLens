import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import Stripe from 'stripe'
import { createClient } from '@supabase/supabase-js'

// Load environment variables
dotenv.config()

const app = express()

// Create Supabase client
const supabase = createClient(
  process.env.VITE_SUPABASE_URL!,
  process.env.VITE_SUPABASE_ANON_KEY!
)

// Initialize Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
  typescript: true
})

// Configure CORS
app.use(cors({
  origin: 'http://localhost:5173',
  credentials: true
}))

// Parse JSON bodies
app.use(express.json())

// API routes
app.post('/api/create-checkout-session', async (req, res) => {
  try {
    const { priceId } = req.body
    
    if (!priceId) {
      return res.status(400).json({ error: 'Price ID is required' })
    }

    const authHeader = req.headers.authorization
    if (!authHeader) {
      return res.status(401).json({ error: 'No authorization header' })
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    )
    
    if (authError || !user) {
      return res.status(401).json({ 
        error: authError?.message || 'User not found'
      })
    }

    // Get or create Stripe customer
    const { data: userData } = await supabase
      .from('users')
      .select('stripe_customer_id')
      .eq('id', user.id)
      .single()

    let customerId = userData?.stripe_customer_id

    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        metadata: { supabase_user_id: user.id }
      })
      customerId = customer.id

      await supabase
        .from('users')
        .update({ stripe_customer_id: customerId })
        .eq('id', user.id)
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${req.headers.origin}/welcome?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${req.headers.origin}/subscription`,
      metadata: { user_id: user.id }
    })

    if (!session?.id) {
      return res.status(500).json({ error: 'Failed to create checkout session' })
    }

    return res.status(200).json({ sessionId: session.id })
  } catch (error) {
    console.error('Checkout error:', error)
    return res.status(500).json({ 
      error: error instanceof Error ? error.message : 'Checkout failed'
    })
  }
})

// Verify payment and update subscription status
app.post('/api/verify-payment', async (req, res) => {
  try {
    const { sessionId } = req.body

    if (!sessionId) {
      return res.status(400).json({ error: 'Session ID is required' })
    }

    // Retrieve the checkout session
    const session = await stripe.checkout.sessions.retrieve(sessionId)
    
    if (session.payment_status !== 'paid') {
      return res.status(400).json({ error: 'Payment not completed' })
    }

    // Get the user ID from the session metadata
    const userId = session.metadata?.user_id
    if (!userId) {
      return res.status(400).json({ error: 'User ID not found in session metadata' })
    }

    // Update the user's subscription status
    const { error: updateError } = await supabase
      .from('users')
      .update({ 
        subscription_status: 'active',
        stripe_subscription_id: session.subscription
      })
      .eq('id', userId)

    if (updateError) {
      throw updateError
    }

    return res.json({ success: true })
  } catch (error) {
    console.error('Payment verification error:', error)
    return res.status(500).json({ 
      error: error instanceof Error ? error.message : 'Failed to verify payment'
    })
  }
})

const port = process.env.PORT || 3001
app.listen(port, () => {
  console.log(`API server running at http://localhost:${port}`)
})