-- Ensure updated_at column exists and has proper defaults
DO $$ 
BEGIN
  -- First ensure the users table exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_name = 'users' AND table_schema = 'public'
  ) THEN
    CREATE TABLE public.users (
      id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
      email text NOT NULL,
      full_name text,
      job_title text,
      company_name text,
      company_products text,
      subscription_status text CHECK (subscription_status IN ('active', 'canceled', 'past due')),
      created_at timestamptz DEFAULT now(),
      updated_at timestamptz DEFAULT now()
    );

    -- Enable RLS
    ALTER TABLE users ENABLE ROW LEVEL SECURITY;

    -- Recreate policies
    CREATE POLICY "Users can read own data"
      ON users FOR SELECT
      TO authenticated
      USING (auth.uid() = id);

    CREATE POLICY "Users can update own data"
      ON users FOR UPDATE
      TO authenticated
      USING (auth.uid() = id)
      WITH CHECK (auth.uid() = id);

    CREATE POLICY "Users can insert own data"
      ON users FOR INSERT
      TO authenticated
      WITH CHECK (auth.uid() = id);
  ELSE
    -- Ensure updated_at column exists with proper default
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns 
      WHERE table_name = 'users' 
      AND column_name = 'updated_at'
      AND table_schema = 'public'
    ) THEN
      ALTER TABLE users ADD COLUMN updated_at timestamptz DEFAULT now();
    END IF;

    -- Ensure created_at column exists with proper default
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns 
      WHERE table_name = 'users' 
      AND column_name = 'created_at'
      AND table_schema = 'public'
    ) THEN
      ALTER TABLE users ADD COLUMN created_at timestamptz DEFAULT now();
    END IF;
  END IF;

  -- Set proper permissions
  GRANT ALL ON public.users TO postgres;
  GRANT ALL ON public.users TO service_role;
  GRANT SELECT, UPDATE ON public.users TO authenticated;
  GRANT SELECT ON public.users TO anon;
END $$;