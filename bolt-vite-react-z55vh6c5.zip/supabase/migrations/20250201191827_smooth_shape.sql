/*
  # Create users table

  1. New Tables
    - `users`
      - `id` (uuid, primary key): References auth.users
      - `email` (text): User's email address
      - `full_name` (text): User's full name
      - `job_title` (text): User's job title
      - `company_name` (text): Name of the user's company
      - `company_products` (text): Description of company's products/services
      - `created_at` (timestamptz): Record creation timestamp
      - `updated_at` (timestamptz): Record update timestamp

  2. Security
    - Enable RLS on `users` table
    - Add policies for:
      - Users can read their own data
      - Users can update their own data
      - Users can insert their own data
*/

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email text NOT NULL,
  full_name text,
  job_title text,
  company_name text,
  company_products text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own data"
  ON users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);