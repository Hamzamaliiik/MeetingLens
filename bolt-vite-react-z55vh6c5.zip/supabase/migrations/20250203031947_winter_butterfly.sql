/*
  # Create meeting briefs table

  1. New Tables
    - `meeting_briefs`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references users.id)
      - `meeting_date` (timestamptz)
      - `target_company_url` (text)
      - `target_company_name` (text)
      - `attendee_name` (text)
      - `industry` (text)
      - `founded_year` (text)
      - `location` (text)
      - `estimated_revenue` (text)
      - `employee_count` (integer)
      - `socials_url` (text)
      - `about` (text)
      - `target_company_products` (text)
      - `what_we_know` (text)
      - `attendee_linkedin_url` (text)
      - `attendee_title` (text)
      - `document_url` (text)
      - `generated_questions` (jsonb)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `meeting_briefs` table
    - Add policies for authenticated users to:
      - Read their own briefs
      - Create new briefs
      - Update their own briefs
      - Delete their own briefs
*/

-- Create meeting_briefs table
CREATE TABLE IF NOT EXISTS public.meeting_briefs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users ON DELETE CASCADE NOT NULL,
  meeting_date timestamptz NOT NULL,
  target_company_url text NOT NULL,
  target_company_name text NOT NULL,
  attendee_name text NOT NULL,
  industry text NOT NULL,
  founded_year text NOT NULL,
  location text NOT NULL,
  estimated_revenue text NOT NULL,
  employee_count integer NOT NULL DEFAULT 0,
  socials_url text NOT NULL DEFAULT '',
  about text NOT NULL,
  target_company_products text NOT NULL,
  what_we_know text,
  attendee_linkedin_url text NOT NULL DEFAULT '',
  attendee_title text NOT NULL,
  document_url text NOT NULL DEFAULT '',
  generated_questions jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE public.meeting_briefs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own meeting briefs"
  ON public.meeting_briefs
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create meeting briefs"
  ON public.meeting_briefs
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own meeting briefs"
  ON public.meeting_briefs
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own meeting briefs"
  ON public.meeting_briefs
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Grant necessary permissions
GRANT ALL ON public.meeting_briefs TO postgres, service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.meeting_briefs TO authenticated;
GRANT SELECT ON public.meeting_briefs TO anon;