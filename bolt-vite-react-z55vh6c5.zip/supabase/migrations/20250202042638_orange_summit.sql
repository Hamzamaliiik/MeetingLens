-- Drop existing trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Recreate function with better error handling and validation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email text;
  v_count integer;
BEGIN
  -- Get email with fallback
  v_email := COALESCE(
    NEW.email,
    (NEW.raw_user_meta_data->>'email')::text,
    'unknown@example.com'
  );

  -- Check if user already exists
  SELECT COUNT(*) INTO v_count
  FROM public.users
  WHERE id = NEW.id;

  IF v_count = 0 THEN
    -- Insert new user with retry logic
    BEGIN
      INSERT INTO public.users (
        id,
        email,
        created_at,
        updated_at
      ) VALUES (
        NEW.id,
        v_email,
        NOW(),
        NOW()
      );
    EXCEPTION WHEN unique_violation THEN
      -- If concurrent insert happened, ignore
      NULL;
    WHEN OTHERS THEN
      -- Log other errors but don't fail
      RAISE WARNING 'Error in handle_new_user: %', SQLERRM;
    END;
  END IF;

  RETURN NEW;
END;
$$;

-- Reset permissions
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC;
REVOKE ALL ON public.users FROM PUBLIC;

-- Grant minimal required permissions
ALTER FUNCTION public.handle_new_user() OWNER TO postgres;
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO postgres;
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO service_role;

-- Recreate trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Set table permissions
GRANT ALL ON public.users TO postgres;
GRANT ALL ON public.users TO service_role;
GRANT SELECT, UPDATE ON public.users TO authenticated;
GRANT SELECT ON public.users TO anon;