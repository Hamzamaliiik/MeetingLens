/*
  # Add subscription status to users table

  1. Changes
    - Add subscription_status column to users table with default value 'free'
    - Valid values: 'free', 'basic', 'premium'

  2. Security
    - Maintain existing RLS policies
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'subscription_status'
  ) THEN
    ALTER TABLE users ADD COLUMN subscription_status text DEFAULT 'free' CHECK (subscription_status IN ('free', 'basic', 'premium'));
  END IF;
END $$;