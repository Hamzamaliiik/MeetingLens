/*
  # Fix signup error by improving trigger function

  1. Changes
    - Simplify trigger function to only handle essential fields
    - Add better error handling
    - Ensure proper security context
    - Fix permission issues

  2. Security
    - Maintain RLS policies
    - Set proper function security context
    - Grant minimal required permissions
*/

-- Drop existing trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Recreate function with minimal required fields and proper security
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email text;
BEGIN
  -- Get email from either direct field or metadata
  v_email := COALESCE(NEW.email, (NEW.raw_user_meta_data->>'email')::text);
  
  -- Simple insert with only required fields
  INSERT INTO public.users (id, email)
  VALUES (NEW.id, v_email);
  
  RETURN NEW;
EXCEPTION WHEN unique_violation THEN
  -- Ignore duplicate key violations
  RETURN NEW;
WHEN OTHERS THEN
  -- Log other errors but don't fail the trigger
  RAISE WARNING 'Error in handle_new_user: %', SQLERRM;
  RETURN NEW;
END;
$$;

-- Reset all permissions
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC;
REVOKE ALL ON public.users FROM PUBLIC;

-- Grant minimal required permissions
ALTER FUNCTION public.handle_new_user() OWNER TO postgres;
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO postgres;
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO service_role;

-- Recreate trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Set table permissions
GRANT ALL ON public.users TO postgres;
GRANT ALL ON public.users TO service_role;
GRANT SELECT, UPDATE ON public.users TO authenticated;
GRANT SELECT ON public.users TO anon;