/*
  # Add user profile columns

  1. Changes
    - Add missing profile columns to users table:
      - job_title (text)
      - company_name (text)
      - company_products (text)

  2. Notes
    - Uses IF NOT EXISTS to prevent errors if columns already exist
    - Maintains existing data
*/

DO $$ 
BEGIN
  -- Add job_title if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'job_title'
  ) THEN
    ALTER TABLE users ADD COLUMN job_title text;
  END IF;

  -- Add company_name if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'company_name'
  ) THEN
    ALTER TABLE users ADD COLUMN company_name text;
  END IF;

  -- Add company_products if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'company_products'
  ) THEN
    ALTER TABLE users ADD COLUMN company_products text;
  END IF;
END $$;