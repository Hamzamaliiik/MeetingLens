/*
  # Update subscription status to match Stripe values

  1. Changes
    - Drop existing check constraint on subscription_status
    - Add new check constraint with Stripe values
    - Set default to NULL since Stripe manages this field

  2. Security
    - Maintains existing RLS policies
*/

-- First remove the existing check constraint
DO $$ 
BEGIN
  ALTER TABLE users 
    DROP CONSTRAINT IF EXISTS users_subscription_status_check;
    
  -- Add new check constraint with Stripe values
  ALTER TABLE users
    ADD CONSTRAINT users_subscription_status_check 
    CHECK (subscription_status IN ('active', 'canceled', 'past due'));
    
  -- Update default to NULL since Stripe manages this
  ALTER TABLE users 
    ALTER COLUMN subscription_status DROP DEFAULT;
END $$;