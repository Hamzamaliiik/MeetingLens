/*
  # Add RLS policies for meeting_briefs table

  1. Security
    - Enable RLS on meeting_briefs table if not already enabled
    - Add policies for authenticated users to:
      - Read their own meeting briefs
      - Create new meeting briefs
      - Update their own meeting briefs
      - Delete their own meeting briefs
*/

-- Enable RLS
ALTER TABLE public.meeting_briefs ENABLE ROW LEVEL SECURITY;

-- Policy for users to read their own meeting briefs
CREATE POLICY IF NOT EXISTS "Users can read own meeting briefs"
  ON public.meeting_briefs
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Policy for users to insert their own meeting briefs
CREATE POLICY IF NOT EXISTS "Users can create meeting briefs"
  ON public.meeting_briefs
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Policy for users to update their own meeting briefs
CREATE POLICY IF NOT EXISTS "Users can update own meeting briefs"
  ON public.meeting_briefs
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policy for users to delete their own meeting briefs
CREATE POLICY IF NOT EXISTS "Users can delete own meeting briefs"
  ON public.meeting_briefs
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Grant necessary permissions
GRANT ALL ON public.meeting_briefs TO postgres, service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.meeting_briefs TO authenticated;
GRANT SELECT ON public.meeting_briefs TO anon;