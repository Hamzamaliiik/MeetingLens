import React from 'react'
import { ArrowLeft } from 'lucide-react'
import { useNavigate } from 'react-router-dom'

type FixedHeaderProps = {
  title: string
  children?: React.ReactNode
}

export default function FixedHeader({ title, children }: FixedHeaderProps) {
  const navigate = useNavigate()

  return (
    <>
      <header className="fixed top-0 left-0 right-0 bg-white border-b border-sage-200 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={() => navigate('/dashboard')}
                className="flex items-center text-sage-600 hover:text-sage-800"
              >
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Dashboard
              </button>
            </div>
            <h1 className="text-xl font-semibold text-sage-800">{title}</h1>
            <div className="flex items-center gap-4">
              {children}
            </div>
          </div>
        </div>
      </header>
      <div className="h-16" /> {/* Spacer to prevent content from going under fixed header */}
    </>
  )
}