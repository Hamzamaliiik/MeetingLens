import React, { useEffect, useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom'
import Login from './pages/Login'
import SignUp from './pages/SignUp'
import Onboarding from './pages/Onboarding'
import SubscriptionPlans from './pages/SubscriptionPlans'
import Dashboard from './pages/Dashboard'
import NewBrief from './pages/NewBrief'
import MeetingBriefDetails from './pages/MeetingBriefDetails'
import EditBrief from './pages/EditBrief'
import Account from './pages/Account'
import { getUserProfile, supabase } from './lib/supabase'

type UserProfile = {
  id: string
  email: string
  full_name: string | null
  job_title: string | null
  company_name: string | null
  company_products: string | null
  subscription_status: 'active' | 'canceled' | 'past due' | null
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate()
  const location = useLocation()
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession()
        
        if (!session) {
          setIsAuthenticated(false)
          navigate('/login', { state: { from: location.pathname } })
          setLoading(false)
          return
        }

        const profile = await getUserProfile()
        setUserProfile(profile)
        setIsAuthenticated(true)
        setLoading(false)
      } catch (error) {
        console.error('Auth check error:', error)
        setIsAuthenticated(false)
        setLoading(false)
        navigate('/login', { state: { from: location.pathname } })
      }
    }

    checkAuth()

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN') {
        const profile = await getUserProfile()
        setUserProfile(profile)
        setIsAuthenticated(true)
      } else if (event === 'SIGNED_OUT') {
        setIsAuthenticated(false)
        setUserProfile(null)
        navigate('/login', { state: { from: location.pathname } })
      }
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [navigate, location])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sage-50 to-sage-200 flex items-center justify-center">
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl shadow-sage-200/50 p-8">
          <p className="text-sage-800 text-xl font-medium">Loading...</p>
        </div>
      </div>
    )
  }

  if (isAuthenticated && userProfile) {
    const currentPath = location.pathname
    const isOnboarding = currentPath === '/onboarding'
    const isSubscription = currentPath === '/subscription'

    if (!userProfile.full_name && !isOnboarding) {
      return <Navigate to="/onboarding" replace />
    }

    if (userProfile.full_name && !userProfile.subscription_status && !isSubscription) {
      return <Navigate to="/subscription" replace />
    }
  }

  return isAuthenticated ? <>{children}</> : null
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/onboarding" element={
          <ProtectedRoute>
            <Onboarding />
          </ProtectedRoute>
        } />
        <Route path="/subscription" element={
          <ProtectedRoute>
            <SubscriptionPlans />
          </ProtectedRoute>
        } />
        <Route path="/dashboard" element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        } />
        <Route path="/briefs/new" element={
          <ProtectedRoute>
            <NewBrief />
          </ProtectedRoute>
        } />
        <Route path="/meeting-brief/:id" element={
          <ProtectedRoute>
            <MeetingBriefDetails />
          </ProtectedRoute>
        } />
        <Route path="/meeting-brief/:id/edit" element={
          <ProtectedRoute>
            <EditBrief />
          </ProtectedRoute>
        } />
        <Route path="/account" element={
          <ProtectedRoute>
            <Account />
          </ProtectedRoute>
        } />
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Router>
  )
}

export default App