import { createClient } from '@supabase/supabase-js'
import type { Database } from '../types/database'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase credentials')
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  },
  db: {
    schema: 'public'
  }
})

// Helper to get the current user
export const getCurrentUser = async () => {
  try {
    const { data: { user }, error } = await supabase.auth.getUser()
    if (error) throw error
    return user
  } catch (error) {
    console.error('Error getting user:', error)
    return null
  }
}

// Helper to check if user exists in users table
export const checkUserExists = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('id')
      .eq('id', userId)
      .single()
      
    if (error) throw error
    return !!data
  } catch (error) {
    console.error('Error checking user:', error)
    return false
  }
}

// Helper to get user profile with subscription status
export const getUserProfile = async () => {
  try {
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError) throw authError
    if (!user) return null

    // Function to fetch profile with retry
    const fetchProfile = async (retries = 3, delay = 1000): Promise<any> => {
      try {
        const { data, error } = await supabase
          .from('users')
          .select('id, email, full_name, job_title, company_name, company_products, subscription_status, updated_at')
          .eq('id', user.id)
          .single()

        if (error) throw error
        return data
      } catch (error) {
        if (retries > 0) {
          await new Promise(resolve => setTimeout(resolve, delay))
          return fetchProfile(retries - 1, delay * 1.5)
        }
        throw error
      }
    }

    return await fetchProfile()
  } catch (error) {
    console.error('Error fetching user profile:', error)
    return null
  }
}

// Meeting briefs helpers
export const getMeetingBriefs = async () => {
  try {
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError) throw authError
    if (!user) return []

    const { data, error } = await supabase
      .from('meeting_briefs')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })

    if (error) throw error
    return data
  } catch (error) {
    console.error('Error fetching meeting briefs:', error)
    return []
  }
}

export const createMeetingBrief = async (brief: Database['public']['Tables']['meeting_briefs']['Insert']) => {
  try {
    const { data, error } = await supabase
      .from('meeting_briefs')
      .insert(brief)
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error) {
    console.error('Error creating meeting brief:', error)
    throw error
  }
}

export const updateMeetingBrief = async (
  id: string, 
  updates: Database['public']['Tables']['meeting_briefs']['Update']
) => {
  try {
    const { data, error } = await supabase
      .from('meeting_briefs')
      .update(updates)
      .eq('id', id)
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error) {
    console.error('Error updating meeting brief:', error)
    throw error
  }
}

export const deleteMeetingBrief = async (id: string) => {
  try {
    const { error } = await supabase
      .from('meeting_briefs')
      .delete()
      .eq('id', id)

    if (error) throw error
    return true
  } catch (error) {
    console.error('Error deleting meeting brief:', error)
    throw error
  }
}