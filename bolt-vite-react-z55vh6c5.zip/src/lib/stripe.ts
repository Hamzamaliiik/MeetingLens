import { loadStripe } from '@stripe/stripe-js'

const stripePublicKey = import.meta.env.VITE_STRIPE_PUBLIC_KEY

if (!stripePublicKey) {
  console.error('Missing Stripe public key')
  throw new Error('Missing Stripe public key')
}

// Initialize Stripe once and cache the promise
const stripePromise = loadStripe(stripePublicKey)

export default stripePromise