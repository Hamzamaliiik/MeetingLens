import { Document, Packer, Paragraph, TextRun, Footer, Header, AlignmentType, PageNumber } from "docx";
import { saveAs } from "file-saver";
import type { Database } from '../types/database'

type MeetingBrief = Database['public']['Tables']['meeting_briefs']['Row']

function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleString("en-US", { 
    dateStyle: "long", 
    timeStyle: "short" 
  });
}

function parseMarkdownContent(content: string) {
  const lines = content.split('\n');
  const sections: { title?: string; subheading?: string; items: string[] }[] = [];
  let currentSection: { title?: string; subheading?: string; items: string[] } = { items: [] };

  lines.forEach(line => {
    const trimmedLine = line.trim();
    if (trimmedLine.startsWith('# ')) {
      // Main heading
      if (currentSection.title || currentSection.items.length > 0) {
        sections.push(currentSection);
      }
      currentSection = {
        title: trimmedLine.replace(/^# /, '').replace(/\*\*/g, ''),
        items: []
      };
    } else if (trimmedLine.startsWith('## ')) {
      // Subheading
      currentSection.subheading = trimmedLine.replace(/^## /, '').replace(/\*\*/g, '');
    } else if (trimmedLine.startsWith('- ')) {
      // Bullet point
      currentSection.items.push(trimmedLine.replace(/^- /, '').replace(/\*\*/g, ''));
    }
  });

  if (currentSection.title || currentSection.items.length > 0) {
    sections.push(currentSection);
  }

  return sections;
}

function formatQuestions(questions: Record<string, any> | string): { stage: string; questions: string[] }[] {
  // If questions is a string (markdown), parse it into our structure
  if (typeof questions === 'string') {
    const lines = questions.split('\n');
    let currentStage = '';
    let currentQuestions: string[] = [];
    const stages: { stage: string; questions: string[] }[] = [];

    lines.forEach(line => {
      const trimmedLine = line.trim();
      
      // Check for stage headers (### or ##)
      if (trimmedLine.startsWith('###') || trimmedLine.startsWith('##')) {
        // When we find a new stage header, save the previous stage if it exists
        if (currentStage && currentQuestions.length > 0) {
          stages.push({
            stage: currentStage,
            questions: [...currentQuestions]
          });
        }
        // Start new stage, remove markdown formatting
        currentStage = trimmedLine.replace(/^#+\s*/, '').replace(/\*\*/g, '').trim();
        currentQuestions = [];
      }
      // Check for numbered items (e.g., "1. **Q1:**")
      else if (/^\d+\.\s*/.test(trimmedLine)) {
        // Clean up the question text
        let questionText = trimmedLine
          .replace(/^\d+\.\s*/, '') // Remove the number
          .replace(/\*\*Q\d+:\*\*\s*/, '') // Remove "**Q1:**" format
          .replace(/\*\*Q\d+:\s*/, '') // Remove "**Q1:" format
          .replace(/Q\d+:\s*/, '') // Remove "Q1:" format
          .replace(/\*\*/g, '') // Remove any remaining asterisks
          .trim();

        // Skip if it's a purpose line
        if (!questionText.toLowerCase().startsWith('purpose:')) {
          currentQuestions.push(questionText);
        }
      }
    });

    // Add the last stage if it exists
    if (currentStage && currentQuestions.length > 0) {
      stages.push({
        stage: currentStage,
        questions: currentQuestions
      });
    }

    return stages;
  }

  // If not a string, handle as before
  if (!questions || typeof questions !== 'object') {
    return [];
  }

  const formattedStages: { stage: string; questions: string[] }[] = [];

  Object.entries(questions).forEach(([stage, stageData]) => {
    const stageQuestions: string[] = [];

    if (typeof stageData === 'object' && stageData !== null) {
      Object.entries(stageData).forEach(([questionId, questionData]) => {
        if (typeof questionData === 'string') {
          const questionText = questionData.replace(/^Q\d+:\s*/, '').trim();
          stageQuestions.push(questionText);
        } else if (typeof questionData === 'object' && questionData !== null) {
          const questionText = questionData.text || questionData.question || '';
          if (questionText) {
            stageQuestions.push(questionText.trim());
          }
        }
      });
    }

    if (stageQuestions.length > 0) {
      formattedStages.push({
        stage: stage.trim(),
        questions: stageQuestions
      });
    }
  });

  return formattedStages;
}

export const exportBrief = async (brief: MeetingBrief): Promise<void> => {
  // Parse the products and solutions content
  const productSections = parseMarkdownContent(brief.target_company_products);
  const discoveryQuestions = formatQuestions(brief.generated_questions);

  const doc = new Document({
    styles: {
      default: {
        document: {
          run: {
            font: "Calibri",
          },
        },
      },
    },
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: 1440,
              right: 1440,
              bottom: 1440,
              left: 1440,
            },
          },
        },
        headers: {
          default: new Header({
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: "Meeting Brief",
                    bold: true,
                    size: 32,
                    font: "Calibri",
                  }),
                ],
                alignment: AlignmentType.CENTER,
                spacing: { after: 200 },
              }),
            ],
          }),
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: "Created by MeetingLens",
                    size: 24,
                    color: "808080",
                    bold: true,
                    font: "Calibri",
                  }),
                ],
                alignment: AlignmentType.CENTER,
              }),
              new Paragraph({
                children: [
                  new TextRun({
                    children: [PageNumber.CURRENT],
                    size: 20,
                    font: "Calibri",
                  }),
                  new TextRun({
                    text: " of ",
                    size: 20,
                    font: "Calibri",
                  }),
                  new TextRun({
                    children: [PageNumber.TOTAL_PAGES],
                    size: 20,
                    font: "Calibri",
                  }),
                ],
                alignment: AlignmentType.CENTER,
              }),
            ],
          }),
        },
        children: [
          // Company Name
          new Paragraph({
            children: [
              new TextRun({
                text: brief.target_company_name,
                bold: true,
                size: 36,
                font: "Calibri",
              }),
            ],
            spacing: { after: 400 },
          }),

          // Company URL
          new Paragraph({
            children: [
              new TextRun({
                text: brief.target_company_url,
                size: 24,
                color: "0000FF",
                underline: {},
                font: "Calibri",
              }),
            ],
            spacing: { after: 400 },
          }),

          // Meeting Date and Time
          new Paragraph({
            children: [
              new TextRun({
                text: "Meeting Date and Time: ",
                bold: true,
                size: 24,
                font: "Calibri",
              }),
              new TextRun({
                text: formatDate(brief.meeting_date),
                size: 24,
                font: "Calibri",
              }),
            ],
            spacing: { after: 400 },
          }),

          // Attendee Information
          new Paragraph({
            children: [
              new TextRun({
                text: "Attendee Information",
                bold: true,
                size: 28,
                font: "Calibri",
              }),
            ],
            spacing: { before: 400, after: 200 },
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: brief.attendee_name,
                size: 24,
                font: "Calibri",
              }),
              ...(brief.attendee_title ? [
                new TextRun({
                  text: `, ${brief.attendee_title}`,
                  size: 24,
                  font: "Calibri",
                }),
              ] : []),
            ],
            spacing: { after: 200 },
          }),
          ...(brief.attendee_linkedin_url ? [
            new Paragraph({
              children: [
                new TextRun({
                  text: "LinkedIn: ",
                  size: 24,
                  font: "Calibri",
                }),
                new TextRun({
                  text: brief.attendee_linkedin_url,
                  size: 24,
                  color: "0000FF",
                  underline: {},
                  font: "Calibri",
                }),
              ],
              spacing: { after: 400 },
            }),
          ] : []),

          // About Section
          new Paragraph({
            children: [
              new TextRun({
                text: "About",
                bold: true,
                size: 28,
                font: "Calibri",
              }),
            ],
            spacing: { before: 400, after: 200 },
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: brief.about.replace(/\*\*/g, '').replace(/^#+\s+/gm, '').trim(),
                size: 24,
                font: "Calibri",
              }),
            ],
            spacing: { after: 400 },
          }),

          // Company Products and Solutions
          new Paragraph({
            children: [
              new TextRun({
                text: "Company Products and Solutions",
                bold: true,
                size: 32,
                font: "Calibri",
              }),
            ],
            spacing: { before: 400, after: 300 },
          }),
          ...productSections.flatMap(section => [
            // Section Title (if exists)
            ...(section.title ? [
              new Paragraph({
                children: [
                  new TextRun({
                    text: section.title,
                    bold: true,
                    size: 28,
                    font: "Calibri",
                    color: "000000",
                  }),
                ],
                spacing: { before: 240, after: 160 },
              }),
            ] : []),
            // Subheading (if exists)
            ...(section.subheading ? [
              new Paragraph({
                children: [
                  new TextRun({
                    text: section.subheading,
                    italics: true,
                    size: 24,
                    font: "Calibri",
                    color: "666666",
                  }),
                ],
                spacing: { before: 160, after: 120 },
                indent: { left: 360 },
              }),
            ] : []),
            // Bullet points
            ...section.items.map(item => 
              new Paragraph({
                bullet: { level: 0 },
                children: [
                  new TextRun({
                    text: item,
                    size: 24,
                    font: "Calibri",
                  }),
                ],
                spacing: { after: 120 },
                indent: { left: 720, hanging: 360 },
              })
            ),
          ]),

          // Company Details
          new Paragraph({
            children: [
              new TextRun({
                text: "Company Details",
                bold: true,
                size: 28,
                font: "Calibri",
              }),
            ],
            spacing: { before: 400, after: 200 },
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: "Founded: ",
                bold: true,
                size: 24,
                font: "Calibri",
              }),
              new TextRun({
                text: brief.founded_year,
                size: 24,
                font: "Calibri",
              }),
            ],
            spacing: { after: 200 },
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: "Industry: ",
                bold: true,
                size: 24,
                font: "Calibri",
              }),
              new TextRun({
                text: brief.industry,
                size: 24,
                font: "Calibri",
              }),
            ],
            spacing: { after: 200 },
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: "Estimated Revenue: ",
                bold: true,
                size: 24,
                font: "Calibri",
              }),
              new TextRun({
                text: brief.estimated_revenue,
                size: 24,
                font: "Calibri",
              }),
            ],
            spacing: { after: 200 },
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: "Employee Count: ",
                bold: true,
                size: 24,
                font: "Calibri",
              }),
              new TextRun({
                text: brief.employee_count.toLocaleString(),
                size: 24,
                font: "Calibri",
              }),
            ],
            spacing: { after: 400 },
          }),

          // What We Know Section
          ...(brief.what_we_know ? [
            new Paragraph({
              children: [
                new TextRun({
                  text: "What We Know",
                  bold: true,
                  size: 28,
                  font: "Calibri",
                }),
              ],
              spacing: { before: 400, after: 200 },
            }),
            new Paragraph({
              children: [
                new TextRun({
                  text: brief.what_we_know.replace(/\*\*/g, '').replace(/^#+\s+/gm, '').trim(),
                  size: 24,
                  font: "Calibri",
                }),
              ],
              spacing: { after: 400 },
            }),
          ] : []),

          // Discovery Questions Section
          ...(discoveryQuestions.length > 0 ? [
            new Paragraph({
              children: [
                new TextRun({
                  text: "Discovery Questions",
                  bold: true,
                  size: 28,
                  font: "Calibri",
                }),
              ],
              spacing: { before: 400, after: 200 },
            }),
            ...discoveryQuestions.flatMap(stage => [
              // Stage header
              new Paragraph({
                children: [
                  new TextRun({
                    text: stage.stage,
                    bold: true,
                    size: 24,
                    font: "Calibri",
                  }),
                ],
                spacing: { before: 200, after: 120 },
              }),
              // Questions in the stage
              ...stage.questions.map((question, index) =>
                new Paragraph({
                  bullet: { level: 0 },
                  children: [
                    new TextRun({
                      text: question,
                      size: 24,
                      font: "Calibri",
                    }),
                  ],
                  spacing: { after: index === stage.questions.length - 1 ? 200 : 120 },
                  indent: { left: 720, hanging: 360 },
                })
              ),
            ]),
          ] : []),
        ],
      },
    ],
  });

  try {
    const blob = await Packer.toBlob(doc);
    const fileName = `${brief.target_company_name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}_meeting_brief.docx`;
    saveAs(blob, fileName);
  } catch (error) {
    console.error('Error generating document:', error);
    throw new Error('Failed to generate document');
  }
}