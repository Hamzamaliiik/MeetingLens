import React, { useState, useEffect } from 'react'
import { Check, Loader2, AlertCircle } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import stripePromise from '../lib/stripe'
import { supabase } from '../lib/supabase'

type BillingPeriod = 'monthly' | 'annually'

const plans = {
  monthly: [
    {
      name: 'Pro',
      price: '$10',
      features: [
        'Unlimited meeting briefs',
        'Priority support',
        'All platform features'
      ],
      stripePriceId: 'price_1Qlam0JqgrHLXf0rSRKy8tYq'
    }
  ],
  annually: [
    {
      name: 'Pro',
      price: '$90',
      savings: '$30',
      features: [
        'Unlimited meeting briefs',
        'Priority support',
        'All platform features'
      ],
      stripePriceId: 'price_1Qlam0JqgrHLXf0rUOLLTrMs'
    }
  ]
}

export default function SubscriptionPlans() {
  const navigate = useNavigate()
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [billingPeriod, setBillingPeriod] = useState<BillingPeriod>('monthly')
  const [isPreviewEnvironment, setIsPreviewEnvironment] = useState(false)

  useEffect(() => {
    // Check if we're in a preview environment (non-HTTPS)
    setIsPreviewEnvironment(!window.location.protocol.includes('https'))
  }, [])

  const handleSelectPlan = async (stripePriceId: string) => {
    // If in preview, show the limitation message instead of proceeding
    if (isPreviewEnvironment) {
      setError('Stripe Checkout requires HTTPS and cannot be opened in the preview environment. Please deploy the application to test the checkout flow.')
      return
    }

    setSelectedPlan(stripePriceId)
    setLoading(true)
    setError(null)
    
    try {
      const stripe = await stripePromise
      if (!stripe) {
        throw new Error('Failed to initialize Stripe')
      }

      const { data: { session }, error: sessionError } = await supabase.auth.getSession()
      if (sessionError) {
        throw new Error(`Session error: ${sessionError.message}`)
      }
      if (!session) {
        throw new Error('Please log in to continue')
      }

      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`
        },
        body: JSON.stringify({ priceId: stripePriceId })
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Failed to parse error response' }))
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
      }

      const data = await response.json()
      if (!data.sessionId) {
        throw new Error('No session ID returned from server')
      }

      const { error: redirectError } = await stripe.redirectToCheckout({ 
        sessionId: data.sessionId 
      })
      
      if (redirectError) {
        throw redirectError
      }
    } catch (err) {
      console.error('Checkout error:', err)
      setError(err instanceof Error ? err.message : 'Failed to start checkout')
    } finally {
      setLoading(false)
    }
  }

  const currentPlans = plans[billingPeriod]

  return (
    <div className="min-h-screen bg-gradient-to-br from-sage-50 to-sage-200 py-12 px-4">
      <div className="max-w-3xl mx-auto">
        {isPreviewEnvironment && (
          <div className="mb-8 bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium text-amber-800">Preview Environment Notice</h3>
              <p className="text-amber-700 text-sm mt-1">
                Stripe Checkout requires HTTPS and cannot be opened in this preview environment. 
                To test the complete checkout flow, please deploy the application to a secure environment.
              </p>
            </div>
          </div>
        )}

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-sage-800 mb-4">Choose your billing period</h1>
          <p className="text-lg text-sage-600 max-w-2xl mx-auto mb-8">
            Get started with our Pro plan. Includes a 5-day free trial.
          </p>

          <div className="inline-flex items-center bg-white rounded-lg p-1 shadow-md">
            <button
              onClick={() => setBillingPeriod('monthly')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                billingPeriod === 'monthly'
                  ? 'bg-sage-500 text-white'
                  : 'text-sage-600 hover:text-sage-800'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingPeriod('annually')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                billingPeriod === 'annually'
                  ? 'bg-sage-500 text-white'
                  : 'text-sage-600 hover:text-sage-800'
              }`}
            >
              Annually
              <span className="ml-1 text-xs font-normal text-sage-500">
                (Save 25%)
              </span>
            </button>
          </div>
        </div>

        <div className="max-w-lg mx-auto">
          {error && (
            <div className="mb-6 bg-red-50 border border-red-100 text-red-600 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          {currentPlans.map((plan) => (
            <div
              key={plan.name}
              className="relative bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl shadow-sage-200/50 p-8"
            >
              <div className="text-center">
                <h3 className="text-2xl font-bold text-sage-800 mb-2">{plan.name}</h3>
                <div className="flex items-end justify-center gap-1 mb-2">
                  <span className="text-4xl font-bold text-sage-800">{plan.price}</span>
                  <span className="text-sage-600 mb-1">
                    /{billingPeriod === 'monthly' ? 'mo' : 'yr'}
                  </span>
                </div>
                {plan.savings && (
                  <p className="text-green-600 text-sm font-medium mb-6">
                    Save {plan.savings} per year
                  </p>
                )}

                <ul className="space-y-4 mb-8 text-left">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-3">
                      <Check className="h-5 w-5 text-sage-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sage-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => handleSelectPlan(plan.stripePriceId)}
                  disabled={loading || isPreviewEnvironment}
                  className="w-full flex items-center justify-center gap-2 py-3 px-6 rounded-lg font-medium transition-colors
                    bg-sage-600 text-white hover:bg-sage-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Preparing checkout...
                    </>
                  ) : (
                    'Get Started'
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>

        <p className="text-center text-sage-600 mt-12">
          Questions about our plan? <a href="#" className="text-sage-800 font-medium hover:text-sage-900">Contact our support team</a>
        </p>
      </div>
    </div>
  )
}