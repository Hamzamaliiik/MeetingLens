import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import ReactMarkdown from 'react-markdown'
import { 
  Loader2,
  Link as LinkIcon,
  Calendar as CalendarIcon,
  Download,
  User,
  Building2,
  DollarSign,
  Users
} from 'lucide-react'
import { supabase } from '../lib/supabase'
import type { Database } from '../types/database'
import { exportBrief } from '../utils/exportBrief'
import FixedHeader from '../components/FixedHeader'

type MeetingBrief = Database['public']['Tables']['meeting_briefs']['Row']

const formatQuestions = (questions: Record<string, any> | string): string => {
  // If questions is already a string (markdown), return it as is
  if (typeof questions === 'string') {
    return questions
  }

  // If not an object or empty, return empty string
  if (!questions || typeof questions !== 'object') {
    return ''
  }

  let markdownContent = ''

  // Process each stage/section
  Object.entries(questions).forEach(([stage, stageData], index) => {
    // Add stage header with extra spacing
    markdownContent += `## ${stage}\n\n`

    if (typeof stageData === 'object' && stageData !== null) {
      // Process questions within the stage
      Object.entries(stageData).forEach(([questionId, questionData]) => {
        if (typeof questionData === 'string') {
          // Extract the question text (remove the "Q1:", etc. if present)
          const questionText = questionData.replace(/^Q\d+:\s*/, '').trim()
          markdownContent += `- ${questionText}\n`
        } else if (typeof questionData === 'object' && questionData !== null) {
          // Handle case where question might have additional metadata
          const questionText = questionData.text || questionData.question || ''
          if (questionText) {
            markdownContent += `- ${questionText.trim()}\n`
          }
        }
      })
      // Add extra spacing between sections, except for the last one
      if (index < Object.entries(questions).length - 1) {
        markdownContent += '\n---\n\n'
      }
    }
  })

  return markdownContent.trim()
}

function MeetingBriefDetails() {
  const { id } = useParams()
  const [brief, setBrief] = useState<MeetingBrief | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchBrief = async () => {
      try {
        const { data, error } = await supabase
          .from('meeting_briefs')
          .select('*')
          .eq('id', id)
          .single()

        if (error) throw error
        setBrief(data)
      } catch (err) {
        console.error('Error fetching brief:', err)
        setError(err instanceof Error ? err.message : 'Failed to load meeting brief')
      } finally {
        setLoading(false)
      }
    }

    fetchBrief()
  }, [id])

  const handleExport = async () => {
    if (!brief) return
    try {
      await exportBrief(brief)
    } catch (error) {
      console.error('Error exporting brief:', error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-sage-50 flex items-center justify-center">
        <div className="flex items-center gap-2 text-sage-600">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span>Loading brief details...</span>
        </div>
      </div>
    )
  }

  if (error || !brief) {
    return (
      <div className="min-h-screen bg-sage-50">
        <FixedHeader title="Error" />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-600">
            {error || 'Meeting brief not found'}
          </div>
        </div>
      </div>
    )
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const formattedQuestions = formatQuestions(brief.generated_questions)

  return (
    <div className="min-h-screen bg-sage-50">
      <FixedHeader title={brief.target_company_name}>
        <button
          onClick={handleExport}
          className="flex items-center gap-2 px-4 py-2 bg-sage-600 text-white rounded-lg hover:bg-sage-700 transition-colors"
        >
          <Download className="h-5 w-5" />
          Export Brief
        </button>
      </FixedHeader>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white rounded-xl shadow-sm border border-sage-200 p-8">
          {/* Meeting Date */}
          <div className="flex items-center text-sage-600 mb-6">
            <CalendarIcon className="h-5 w-5 mr-2" />
            <span>{formatDate(brief.meeting_date)}</span>
          </div>

          {/* Company Website */}
          {brief.target_company_url && (
            <a
              href={brief.target_company_url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-sage-600 hover:text-sage-800 mb-8"
            >
              <LinkIcon className="h-5 w-5" />
              Visit Company Website
            </a>
          )}

          {/* Attendee Information */}
          <div className="bg-sage-50 rounded-lg p-6 mb-8">
            <div className="flex items-start gap-4">
              <User className="h-6 w-6 text-sage-600 mt-1" />
              <div>
                <h2 className="text-xl font-semibold text-sage-800 mb-2">Attendee Information</h2>
                <p className="text-sage-700 mb-2">
                  {brief.attendee_name} • {brief.attendee_title}
                </p>
                {brief.attendee_linkedin_url && (
                  <a
                    href={brief.attendee_linkedin_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sage-600 hover:text-sage-800 inline-flex items-center gap-1"
                  >
                    View LinkedIn Profile
                    <LinkIcon className="h-4 w-4" />
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* About Section */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-sage-800 mb-4">About</h2>
            <div className="prose prose-sage max-w-none">
              <ReactMarkdown>{brief.about}</ReactMarkdown>
            </div>
          </div>

          {/* Products and Solutions */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-sage-800 mb-4">Products and Solutions</h2>
            <div className="prose prose-sage max-w-none">
              <ReactMarkdown>{brief.target_company_products}</ReactMarkdown>
            </div>
          </div>

          {/* Company Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="flex items-center gap-3">
              <Building2 className="h-5 w-5 text-sage-600" />
              <div>
                <p className="text-sm text-sage-600">Founded</p>
                <p className="font-medium text-sage-800">{brief.founded_year}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Users className="h-5 w-5 text-sage-600" />
              <div>
                <p className="text-sm text-sage-600">Employees</p>
                <p className="font-medium text-sage-800">{brief.employee_count.toLocaleString()}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <DollarSign className="h-5 w-5 text-sage-600" />
              <div>
                <p className="text-sm text-sage-600">Revenue</p>
                <p className="font-medium text-sage-800">{brief.estimated_revenue}</p>
              </div>
            </div>
          </div>

          {/* What We Know */}
          {brief.what_we_know && (
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-sage-800 mb-4">What We Know</h2>
              <div className="prose prose-sage max-w-none">
                <ReactMarkdown>{brief.what_we_know}</ReactMarkdown>
              </div>
            </div>
          )}

          {/* Discovery Questions */}
          {formattedQuestions && (
            <div>
              <h2 className="text-xl font-semibold text-sage-800 mb-4">Discovery Questions</h2>
              <div className="prose prose-sage max-w-none">
                <ReactMarkdown>{formattedQuestions}</ReactMarkdown>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default MeetingBriefDetails