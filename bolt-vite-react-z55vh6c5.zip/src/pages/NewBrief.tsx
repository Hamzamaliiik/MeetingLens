import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Calendar, Globe, User, Loader2, ArrowLeft, BookOpen } from 'lucide-react'
import { createMeetingBrief, supabase } from '../lib/supabase'
import type { Database } from '../types/database'

type MeetingBriefInsert = Database['public']['Tables']['meeting_briefs']['Insert']

// Helper function to normalize URLs
const normalizeUrl = (url: string): string => {
  // Remove any existing protocol
  let cleanUrl = url.replace(/^(https?:\/\/)/, '')
  
  // Add https:// protocol if missing
  if (!cleanUrl.startsWith('http')) {
    cleanUrl = 'https://' + cleanUrl
  }
  
  return cleanUrl
}

// Helper function to extract domain name
const extractDomainName = (url: string): string => {
  // Remove any protocol and www.
  return url.replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0]
}

export default function NewBrief() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    meeting_date: '',
    target_company_url: '',
    attendee_name: '',
    what_we_know: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      // Basic validation
      if (!formData.meeting_date || !formData.target_company_url || !formData.attendee_name) {
        throw new Error('Please fill in all required fields')
      }

      // Get current user
      const { data: { user }, error: userError } = await supabase.auth.getUser()
      if (userError) throw userError
      if (!user) throw new Error('No authenticated user found')

      // Normalize the URL
      const normalizedUrl = normalizeUrl(formData.target_company_url)

      // Create the brief
      const briefData: MeetingBriefInsert = {
        user_id: user.id, // Set the user_id from the authenticated user
        meeting_date: formData.meeting_date,
        target_company_url: normalizedUrl,
        attendee_name: formData.attendee_name,
        what_we_know: formData.what_we_know || null, // Add what_we_know field
        // Set default values for required fields
        target_company_name: extractDomainName(formData.target_company_url),
        industry: 'Pending',
        founded_year: 'Pending',
        location: 'Pending',
        estimated_revenue: 'Pending',
        employee_count: 0,
        socials_url: '',
        about: 'Pending analysis',
        target_company_products: 'Pending analysis',
        attendee_linkedin_url: '',
        attendee_title: 'Pending',
        document_url: '',
        generated_questions: {}
      }

      await createMeetingBrief(briefData)
      navigate('/dashboard')
    } catch (err) {
      console.error('Error creating brief:', err)
      setError(err instanceof Error ? err.message : 'Failed to create meeting brief')
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  return (
    <div className="min-h-screen bg-sage-50">
      <div className="max-w-3xl mx-auto px-4 py-8">
        <button
          onClick={() => navigate('/dashboard')}
          className="flex items-center text-sage-600 hover:text-sage-800 mb-8"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Dashboard
        </button>

        <div className="bg-white rounded-lg shadow-sm border border-sage-200 p-8">
          <h1 className="text-2xl font-bold text-sage-800 mb-6">Create New Meeting Brief</h1>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="meeting_date" className="block text-sm font-medium text-sage-700 mb-1">
                Meeting Date and Time
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Calendar className="h-5 w-5 text-sage-400" />
                </div>
                <input
                  type="datetime-local"
                  id="meeting_date"
                  name="meeting_date"
                  value={formData.meeting_date}
                  onChange={handleChange}
                  className="block w-full pl-10 pr-3 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="target_company_url" className="block text-sm font-medium text-sage-700 mb-1">
                Target Company Website URL
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Globe className="h-5 w-5 text-sage-400" />
                </div>
                <input
                  type="text"
                  id="target_company_url"
                  name="target_company_url"
                  value={formData.target_company_url}
                  onChange={handleChange}
                  placeholder="example.com"
                  className="block w-full pl-10 pr-3 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                  required
                />
                <p className="mt-1 text-sm text-sage-500">
                  Enter domain only, e.g. "example.com" or "www.example.com"
                </p>
              </div>
            </div>

            <div>
              <label htmlFor="attendee_name" className="block text-sm font-medium text-sage-700 mb-1">
                Attendee Full Name
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-sage-400" />
                </div>
                <input
                  type="text"
                  id="attendee_name"
                  name="attendee_name"
                  value={formData.attendee_name}
                  onChange={handleChange}
                  placeholder="John Doe"
                  className="block w-full pl-10 pr-3 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="what_we_know" className="block text-sm font-medium text-sage-700 mb-1">
                What We Already Know
              </label>
              <div className="relative">
                <div className="absolute top-3 left-3 pointer-events-none">
                  <BookOpen className="h-5 w-5 text-sage-400" />
                </div>
                <textarea
                  id="what_we_know"
                  name="what_we_know"
                  value={formData.what_we_know}
                  onChange={handleChange}
                  placeholder="Enter any existing knowledge about the company or meeting context..."
                  rows={4}
                  className="block w-full pl-10 pr-3 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={loading}
                className="flex items-center gap-2 bg-sage-600 text-white rounded-lg px-6 py-3 hover:bg-sage-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sage-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Creating Brief...
                  </>
                ) : (
                  'Create Brief'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}