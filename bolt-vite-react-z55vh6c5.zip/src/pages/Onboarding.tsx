import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Building2, Briefcase, User, Package, Loader2 } from 'lucide-react'
import { supabase } from '../lib/supabase'

export default function Onboarding() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [pageLoading, setPageLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    fullName: '',
    jobTitle: '',
    companyName: '',
    companyProducts: ''
  })

  // Check authentication status and existing profile on mount
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession()
        
        if (!session) {
          navigate('/login')
          return
        }

        // Check if user already has a profile
        const { data: userData } = await supabase
          .from('users')
          .select('full_name, job_title, company_name, company_products')
          .eq('id', session.user.id)
          .single()

        if (userData?.full_name) {
          // User already completed onboarding
          navigate('/welcome')
          return
        }

        setPageLoading(false)
      } catch (err) {
        console.error('Error checking auth:', err)
        navigate('/login')
      }
    }
    checkAuth()
  }, [navigate])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session?.user) {
        throw new Error('No user found')
      }

      const { error: updateError } = await supabase
        .from('users')
        .update({
          full_name: formData.fullName,
          job_title: formData.jobTitle,
          company_name: formData.companyName,
          company_products: formData.companyProducts,
          updated_at: new Date().toISOString()
        })
        .eq('id', session.user.id)

      if (updateError) throw updateError
      
      navigate('/welcome')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  if (pageLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sage-50 to-sage-200 flex items-center justify-center">
        <div className="flex items-center gap-2 text-sage-600">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span>Loading...</span>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sage-50 to-sage-200 flex items-center justify-center p-4">
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl shadow-sage-200/50 w-full max-w-md p-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-sage-800 mb-2">Complete your profile</h1>
          <p className="text-sage-600">Tell us a bit about yourself</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="fullName" className="block text-sm font-medium text-sage-700 mb-1">
              Full Name
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <User className="h-5 w-5 text-sage-400" />
              </div>
              <input
                id="fullName"
                name="fullName"
                type="text"
                required
                value={formData.fullName}
                onChange={handleChange}
                className="block w-full pl-10 pr-3 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 bg-white/50"
                placeholder="John Doe"
                disabled={loading}
              />
            </div>
          </div>

          <div>
            <label htmlFor="jobTitle" className="block text-sm font-medium text-sage-700 mb-1">
              Job Title
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Briefcase className="h-5 w-5 text-sage-400" />
              </div>
              <input
                id="jobTitle"
                name="jobTitle"
                type="text"
                required
                value={formData.jobTitle}
                onChange={handleChange}
                className="block w-full pl-10 pr-3 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 bg-white/50"
                placeholder="Product Manager"
                disabled={loading}
              />
            </div>
          </div>

          <div>
            <label htmlFor="companyName" className="block text-sm font-medium text-sage-700 mb-1">
              Company Name
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Building2 className="h-5 w-5 text-sage-400" />
              </div>
              <input
                id="companyName"
                name="companyName"
                type="text"
                required
                value={formData.companyName}
                onChange={handleChange}
                className="block w-full pl-10 pr-3 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 bg-white/50"
                placeholder="Acme Inc."
                disabled={loading}
              />
            </div>
          </div>

          <div>
            <label htmlFor="companyProducts" className="block text-sm font-medium text-sage-700 mb-1">
              Company Products/Services
            </label>
            <div className="relative">
              <div className="absolute top-3 left-3 pointer-events-none">
                <Package className="h-5 w-5 text-sage-400" />
              </div>
              <textarea
                id="companyProducts"
                name="companyProducts"
                required
                value={formData.companyProducts}
                onChange={handleChange}
                rows={3}
                className="block w-full pl-10 pr-3 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 bg-white/50"
                placeholder="Describe your company's main products or services"
                disabled={loading}
              />
            </div>
          </div>

          {error && (
            <div className="text-red-500 text-sm mt-2">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 bg-sage-600 text-white rounded-lg px-4 py-3 font-medium hover:bg-sage-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sage-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {loading ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Saving...
              </>
            ) : (
              'Complete Profile'
            )}
          </button>
        </form>
      </div>
    </div>
  )
}