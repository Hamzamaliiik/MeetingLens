import React, { useState, useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { getUserProfile } from '../lib/supabase'
import { Loader2, CheckCircle2 } from 'lucide-react'

type UserProfile = {
  id: string
  email: string
  full_name: string | null
  job_title: string | null
  company_name: string | null
  company_products: string | null
  subscription_status: 'active' | 'canceled' | 'past due' | null
}

export default function Welcome() {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [paymentSuccess, setPaymentSuccess] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const checkPaymentStatus = async () => {
      const searchParams = new URLSearchParams(location.search)
      const sessionId = searchParams.get('session_id')

      if (sessionId) {
        try {
          // Verify the payment status with our backend
          const response = await fetch('/api/verify-payment', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ sessionId })
          })

          if (response.ok) {
            setPaymentSuccess(true)
          }
        } catch (error) {
          console.error('Error verifying payment:', error)
        }
      }

      // Get the latest user profile
      const profile = await getUserProfile()
      setUserProfile(profile)
      setLoading(false)
    }

    checkPaymentStatus()
  }, [location])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sage-50 to-sage-200 flex items-center justify-center">
        <div className="flex items-center gap-2 text-sage-600">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span>Loading...</span>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sage-50 to-sage-200 flex items-center justify-center p-4">
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl shadow-sage-200/50 p-8 max-w-md w-full">
        {paymentSuccess && (
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <div className="rounded-full bg-green-100 p-3">
                <CheckCircle2 className="h-8 w-8 text-green-500" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-sage-800 mb-2">Payment Successful!</h2>
            <p className="text-sage-600">
              Thank you for subscribing. Your account has been upgraded.
            </p>
          </div>
        )}

        <div className="text-center">
          <h1 className="text-3xl font-bold text-sage-800 mb-6">
            Welcome{userProfile?.full_name ? `, ${userProfile.full_name}` : ''}!
          </h1>
          
          {userProfile && (
            <div className="space-y-4">
              <div className="bg-sage-50 rounded-lg p-4">
                <p className="text-sage-600 mb-2">Subscription Status</p>
                <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                  userProfile.subscription_status === 'active' ? 'bg-green-100 text-green-800' :
                  userProfile.subscription_status === 'past due' ? 'bg-orange-100 text-orange-800' :
                  userProfile.subscription_status === 'canceled' ? 'bg-red-100 text-red-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {userProfile.subscription_status ? (
                    userProfile.subscription_status.charAt(0).toUpperCase() + 
                    userProfile.subscription_status.slice(1)
                  ) : 'Not subscribed'}
                </span>
              </div>

              <div className="text-left space-y-3">
                <p className="text-sage-600">
                  <span className="font-medium">Email:</span> {userProfile.email}
                </p>
                {userProfile.job_title && (
                  <p className="text-sage-600">
                    <span className="font-medium">Role:</span> {userProfile.job_title}
                  </p>
                )}
                {userProfile.company_name && (
                  <p className="text-sage-600">
                    <span className="font-medium">Company:</span> {userProfile.company_name}
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}