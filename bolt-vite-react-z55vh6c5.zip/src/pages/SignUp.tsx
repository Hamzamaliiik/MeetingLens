import React, { useState } from 'react'
import { Linkedin, Mail, Lock, Loader2, CheckCircle2 } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { useNavigate } from 'react-router-dom'

export default function SignUp() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showVerificationModal, setShowVerificationModal] = useState(false)

  const handleEmailSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      // First check if user already exists
      const { data: existingUser, error: checkError } = await supabase
        .from('users')
        .select('id')
        .eq('email', email)
        .maybeSingle()

      if (checkError) {
        console.error('Error checking existing user:', checkError)
      }

      if (existingUser) {
        throw new Error('This email is already registered. Please sign in instead.')
      }

      // Attempt signup
      const { data, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            email // Include email in metadata
          }
        }
      })

      if (signUpError) {
        console.error('Signup error:', signUpError)
        throw signUpError
      }

      if (!data.user) {
        throw new Error('No user data returned from signup')
      }

      // Show verification modal instead of navigating
      setShowVerificationModal(true)
    } catch (err) {
      console.error('Signup process error:', err)
      setError(
        err instanceof Error 
          ? err.message 
          : 'An unexpected error occurred. Please try again.'
      )
    } finally {
      setLoading(false)
    }
  }

  const handleLinkedInSignUp = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'linkedin',
        options: {
          redirectTo: `${window.location.origin}/onboarding`
        }
      })
      if (error) throw error
    } catch (err) {
      console.error('LinkedIn signup error:', err)
      setError(err instanceof Error ? err.message : 'An error occurred with LinkedIn signup')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sage-50 to-sage-200 flex items-center justify-center p-4">
      {showVerificationModal ? (
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl shadow-sage-200/50 w-full max-w-md p-8 text-center">
          <div className="flex justify-center mb-6">
            <CheckCircle2 className="h-16 w-16 text-green-500" />
          </div>
          <h2 className="text-2xl font-bold text-sage-800 mb-4">Verify your email</h2>
          <p className="text-sage-600 mb-6">
            We've sent a verification link to <span className="font-medium">{email}</span>. 
            Please check your email and click the link to verify your account.
          </p>
          <div className="space-y-4">
            <button
              onClick={() => navigate('/login')}
              className="w-full flex items-center justify-center gap-2 bg-sage-600 text-white rounded-lg px-4 py-3 font-medium hover:bg-sage-700 transition-colors"
            >
              Go to Login
            </button>
            <p className="text-sm text-sage-500">
              Didn't receive the email? Check your spam folder or{' '}
              <button 
                onClick={handleEmailSignUp}
                className="text-sage-700 hover:text-sage-800 font-medium"
              >
                resend verification email
              </button>
            </p>
          </div>
        </div>
      ) : (
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl shadow-sage-200/50 w-full max-w-md p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-sage-800 mb-2">Create an account</h1>
            <p className="text-sage-600">Join us today</p>
          </div>

          <button
            onClick={handleLinkedInSignUp}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 bg-[#0077B5] text-white rounded-lg px-4 py-3 font-medium hover:bg-[#006399] transition-colors mb-6 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Linkedin size={20} />
            Sign up with LinkedIn
          </button>

          <div className="relative mb-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-sage-200"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-sage-500">Or sign up with email</span>
            </div>
          </div>

          <form onSubmit={handleEmailSignUp} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-sage-700 mb-1">
                Email address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-sage-400" />
                </div>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 bg-white/50"
                  placeholder="you@example.com"
                  required
                  disabled={loading}
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-sage-700 mb-1">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-sage-400" />
                </div>
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500 bg-white/50"
                  placeholder="••••••••"
                  required
                  minLength={6}
                  disabled={loading}
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-50 text-red-600 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-sage-600 text-white rounded-lg px-4 py-3 font-medium hover:bg-sage-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sage-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {loading ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Creating account...
                </>
              ) : (
                'Create account'
              )}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-sage-600">
            Already have an account?{' '}
            <a href="/login" className="font-medium text-sage-600 hover:text-sage-500">
              Sign in
            </a>
          </p>
        </div>
      )}
    </div>
  )
}