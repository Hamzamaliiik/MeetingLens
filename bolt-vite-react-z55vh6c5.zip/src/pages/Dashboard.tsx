import React, { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { 
  Plus, 
  Settings, 
  CreditCard, 
  Loader2, 
  Calendar, 
  Search,
  ChevronDown,
  MoreVertical,
  Clock,
  User,
  Building2,
  Sparkles,
  Pencil,
  Trash2,
  Download
} from 'lucide-react'
import { supabase } from '../lib/supabase'
import type { Database } from '../types/database'
import { exportBrief } from '../utils/exportBrief'

type MeetingBrief = Database['public']['Tables']['meeting_briefs']['Row']
type UserProfile = Database['public']['Tables']['users']['Row']

// URL validation helper
const isValidUrl = (urlString: string): boolean => {
  try {
    if (!urlString) return false
    const urlToTest = urlString.startsWith('http') ? urlString : `https://${urlString}`
    new URL(urlToTest)
    return true
  } catch (e) {
    return false
  }
}

// URL formatting helper
const formatUrl = (url: string): string => {
  if (!url) return ''
  return url.startsWith('http') ? url : `https://${url}`
}

export default function Dashboard() {
  const navigate = useNavigate()
  const [briefs, setBriefs] = useState<MeetingBrief[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [sortBy, setSortBy] = useState<'date' | 'company'>('date')
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [showUserMenu, setShowUserMenu] = useState(false)
  const [activeMenu, setActiveMenu] = useState<string | null>(null)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null)
  const [processingBriefs, setProcessingBriefs] = useState<Set<string>>(new Set())
  
  const userMenuRef = useRef<HTMLDivElement>(null)
  const briefMenuRefs = useRef<{ [key: string]: HTMLDivElement | null }>({})

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false)
      }

      if (activeMenu) {
        const activeMenuRef = briefMenuRefs.current[activeMenu]
        if (activeMenuRef && !activeMenuRef.contains(event.target as Node)) {
          setActiveMenu(null)
        }
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [activeMenu])

  useEffect(() => {
    const fetchBriefsAndProfile = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession()
        if (!session) {
          navigate('/login')
          return
        }

        const { data: profile, error: profileError } = await supabase
          .from('users')
          .select('*')
          .eq('id', session.user.id)
          .single()

        if (profileError) throw profileError
        setUserProfile(profile)

        const { data: briefsData, error: briefsError } = await supabase
          .from('meeting_briefs')
          .select('*')
          .eq('user_id', session.user.id)
          .order('created_at', { ascending: false })

        if (briefsError) throw briefsError
        setBriefs(briefsData || [])

        // Set processing state for recently created briefs
        const now = new Date().getTime()
        const newProcessingBriefs = new Set<string>()
        briefsData?.forEach(brief => {
          const briefCreatedAt = new Date(brief.created_at).getTime()
          const timeSinceCreation = now - briefCreatedAt
          if (timeSinceCreation < 45000) { // 45 seconds
            newProcessingBriefs.add(brief.id)
            setTimeout(() => {
              setProcessingBriefs(prev => {
                const updated = new Set(prev)
                updated.delete(brief.id)
                return updated
              })
            }, Math.max(0, 45000 - timeSinceCreation))
          }
        })
        setProcessingBriefs(newProcessingBriefs)
      } catch (error) {
        console.error('Error fetching data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchBriefsAndProfile()

    const briefsSubscription = supabase
      .channel('meeting_briefs_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'meeting_briefs'
        },
        async (payload) => {
          const { data: { session } } = await supabase.auth.getSession()
          if (!session) return

          const { data: briefsData, error: briefsError } = await supabase
            .from('meeting_briefs')
            .select('*')
            .eq('user_id', session.user.id)
            .order('created_at', { ascending: false })

          if (briefsError) {
            console.error('Error fetching updated briefs:', briefsError)
            return
          }

          setBriefs(briefsData || [])

          // If this is a new brief, set it as processing
          if (payload.eventType === 'INSERT') {
            const newBriefId = payload.new.id
            setProcessingBriefs(prev => new Set([...prev, newBriefId]))
            setTimeout(() => {
              setProcessingBriefs(prev => {
                const updated = new Set(prev)
                updated.delete(newBriefId)
                return updated
              })
            }, 45000)
          }
        }
      )
      .subscribe()

    return () => {
      briefsSubscription.unsubscribe()
    }
  }, [navigate])

  const handleDeleteBrief = async (briefId: string) => {
    try {
      const { error } = await supabase
        .from('meeting_briefs')
        .delete()
        .eq('id', briefId)

      if (error) throw error
      
      setShowDeleteConfirm(null)
      setActiveMenu(null)
    } catch (error) {
      console.error('Error deleting brief:', error)
    }
  }

  const handleExport = async (e: React.MouseEvent, brief: MeetingBrief) => {
    e.stopPropagation()
    try {
      await exportBrief(brief)
    } catch (error) {
      console.error('Error exporting brief:', error)
    }
  }

  const filteredBriefs = briefs
    .filter(brief => 
      brief.target_company_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      brief.about?.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === 'date') {
        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      }
      return a.target_company_name.localeCompare(b.target_company_name)
    })

  if (loading) {
    return (
      <div className="min-h-screen bg-sage-50 flex items-center justify-center">
        <div className="flex items-center gap-2 text-sage-600">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span>Loading your dashboard...</span>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-sage-50">
      <header className="bg-white border-b border-sage-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <h1 className="text-2xl font-bold text-sage-800">Meeting Briefs</h1>
            
            <div className="flex items-center gap-4">
              <div className="relative" ref={userMenuRef}>
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-2 text-sage-700 hover:text-sage-900"
                >
                  <User className="h-5 w-5" />
                  <span className="text-sm font-medium">
                    {userProfile?.full_name || userProfile?.email}
                  </span>
                  <ChevronDown className="h-4 w-4" />
                </button>

                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-sage-200 py-1 z-10">
                    <button
                      onClick={() => navigate('/account')}
                      className="flex items-center gap-2 w-full px-4 py-2 text-sm text-sage-700 hover:bg-sage-50"
                    >
                      <Settings className="h-4 w-4" />
                      Account Settings
                    </button>
                    <button
                      onClick={() => navigate('/subscription')}
                      className="flex items-center gap-2 w-full px-4 py-2 text-sm text-sage-700 hover:bg-sage-50"
                    >
                      <CreditCard className="h-4 w-4" />
                      Manage Subscription
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col sm:flex-row gap-4 sm:items-center justify-between mb-8">
          <div className="flex-1 max-w-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-sage-400" />
              <input
                type="text"
                placeholder="Search companies or briefs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'date' | 'company')}
              className="border border-sage-300 rounded-lg px-3 py-2 bg-white focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
            >
              <option value="date">Sort by Date</option>
              <option value="company">Sort by Company</option>
            </select>

            <button
              onClick={() => navigate('/briefs/new')}
              className="flex items-center gap-2 bg-sage-600 text-white rounded-lg px-4 py-2 hover:bg-sage-700 transition-colors"
            >
              <Plus className="h-5 w-5" />
              New Brief
            </button>
          </div>
        </div>

        {showDeleteConfirm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
              <h3 className="text-lg font-semibold text-sage-800 mb-2">Delete Meeting Brief</h3>
              <p className="text-sage-600 mb-6">
                Are you sure you want to delete this meeting brief? This action cannot be undone.
              </p>
              <div className="flex justify-end gap-4">
                <button
                  onClick={() => setShowDeleteConfirm(null)}
                  className="px-4 py-2 text-sage-600 hover:text-sage-800"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleDeleteBrief(showDeleteConfirm)}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}

        {filteredBriefs.length === 0 ? (
          <div className="text-center py-12">
            <div className="bg-white rounded-lg shadow-sm border border-sage-200 p-8 max-w-md mx-auto">
              <div className="bg-sage-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
                <Sparkles className="h-8 w-8 text-sage-600" />
              </div>
              <h3 className="text-xl font-medium text-sage-900 mb-3">Welcome to Meeting Briefs!</h3>
              <p className="text-sage-600 mb-8">
                {searchQuery 
                  ? "No briefs match your search criteria. Try adjusting your search terms."
                  : "Create your first meeting brief to get insights and prepare for your upcoming meetings."}
              </p>
              {!searchQuery && (
                <button
                  onClick={() => navigate('/briefs/new')}
                  className="inline-flex items-center gap-2 bg-sage-600 text-white rounded-lg px-6 py-3 hover:bg-sage-700 transition-colors mx-auto"
                >
                  <Plus className="h-5 w-5" />
                  Create Your First Brief
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBriefs.map((brief) => (
              <div
                key={brief.id}
                onClick={() => {
                  if (!activeMenu && !processingBriefs.has(brief.id)) {
                    navigate(`/meeting-brief/${brief.id}`)
                  }
                }}
                className="bg-white rounded-lg shadow-sm border border-sage-200 p-6 hover:shadow-md transition-shadow cursor-pointer relative"
              >
                {processingBriefs.has(brief.id) && (
                  <div className="absolute inset-0 bg-white/80 backdrop-blur-sm rounded-lg flex items-center justify-center z-10">
                    <div className="text-center">
                      <Loader2 className="h-8 w-8 animate-spin text-sage-600 mx-auto mb-2" />
                      <p className="text-sage-700 font-medium">Processing brief...</p>
                    </div>
                  </div>
                )}

                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-lg font-medium text-sage-900 line-clamp-2">
                    {isValidUrl(brief.target_company_url) ? (
                      <a
                        href={formatUrl(brief.target_company_url)}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="hover:text-sage-600 transition-colors"
                      >
                        {brief.target_company_name}
                      </a>
                    ) : (
                      brief.target_company_name
                    )}
                  </h3>
                  <div className="relative" ref={(el) => briefMenuRefs.current[brief.id] = el}>
                    <button 
                      className="text-sage-400 hover:text-sage-600 p-1"
                      onClick={(e) => {
                        e.stopPropagation()
                        setActiveMenu(activeMenu === brief.id ? null : brief.id)
                      }}
                    >
                      <MoreVertical className="h-5 w-5" />
                    </button>
                    
                    {activeMenu === brief.id && (
                      <div className="absolute right-0 mt-1 w-48 bg-white rounded-lg shadow-lg border border-sage-200 py-1 z-10">
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            navigate(`/meeting-brief/${brief.id}/edit`)
                            setActiveMenu(null)
                          }}
                          className="flex items-center gap-2 w-full px-4 py-2 text-sm text-sage-700 hover:bg-sage-50"
                        >
                          <Pencil className="h-4 w-4" />
                          Edit Brief
                        </button>
                        <button
                          onClick={(e) => handleExport(e, brief)}
                          className="flex items-center gap-2 w-full px-4 py-2 text-sm text-sage-700 hover:bg-sage-50"
                        >
                          <Download className="h-4 w-4" />
                          Export Brief
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            setShowDeleteConfirm(brief.id)
                            setActiveMenu(null)
                          }}
                          className="flex items-center gap-2 w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                          Delete Brief
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <p className="text-sage-600 mb-4 line-clamp-2">
                  {brief.about}
                </p>

                <div className="flex items-center justify-between text-sm text-sage-500">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    <span>{new Date(brief.meeting_date).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    <span>{new Date(brief.created_at).toLocaleDateString()}</span>
                  </div>
                </div>

                {brief.attendee_name && (
                  <div className="mt-4 pt-4 border-t border-sage-100">
                    <div className="flex items-center gap-2 text-sage-600">
                      <User className="h-4 w-4" />
                      <span className="text-sm">
                        Meeting with {brief.attendee_name}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}