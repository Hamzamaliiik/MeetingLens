import React, { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { Calendar, User, Globe, Loader2, ArrowLeft } from 'lucide-react'
import { supabase } from '../lib/supabase'
import type { Database } from '../types/database'

type MeetingBrief = Database['public']['Tables']['meeting_briefs']['Row']

export default function EditBrief() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    meeting_date: '',
    target_company_url: '',
    attendee_name: ''
  })

  useEffect(() => {
    const fetchBrief = async () => {
      try {
        const { data, error } = await supabase
          .from('meeting_briefs')
          .select('*')
          .eq('id', id)
          .single()

        if (error) throw error
        
        setFormData({
          meeting_date: new Date(data.meeting_date).toISOString().slice(0, 16),
          target_company_url: data.target_company_url || '',
          attendee_name: data.attendee_name || ''
        })
      } catch (err) {
        console.error('Error fetching brief:', err)
        setError(err instanceof Error ? err.message : 'Failed to load meeting brief')
      } finally {
        setLoading(false)
      }
    }

    fetchBrief()
  }, [id])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    setError(null)

    try {
      const { error } = await supabase
        .from('meeting_briefs')
        .update({
          meeting_date: formData.meeting_date,
          target_company_url: formData.target_company_url,
          attendee_name: formData.attendee_name
        })
        .eq('id', id)

      if (error) throw error
      navigate(`/meeting-brief/${id}`)
    } catch (err) {
      console.error('Error updating brief:', err)
      setError(err instanceof Error ? err.message : 'Failed to update meeting brief')
    } finally {
      setSaving(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-sage-50 flex items-center justify-center">
        <div className="flex items-center gap-2 text-sage-600">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span>Loading brief...</span>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-sage-50">
      <div className="max-w-3xl mx-auto px-4 py-8">
        <button
          onClick={() => navigate(`/meeting-brief/${id}`)}
          className="flex items-center text-sage-600 hover:text-sage-800 mb-8"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Brief
        </button>

        <div className="bg-white rounded-lg shadow-sm border border-sage-200 p-8">
          <h1 className="text-2xl font-bold text-sage-800 mb-6">Edit Meeting Brief</h1>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="meeting_date" className="block text-sm font-medium text-sage-700 mb-1">
                Meeting Date and Time
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Calendar className="h-5 w-5 text-sage-400" />
                </div>
                <input
                  type="datetime-local"
                  id="meeting_date"
                  name="meeting_date"
                  value={formData.meeting_date}
                  onChange={handleChange}
                  className="block w-full pl-10 pr-3 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="target_company_url" className="block text-sm font-medium text-sage-700 mb-1">
                Target Company Website URL
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Globe className="h-5 w-5 text-sage-400" />
                </div>
                <input
                  type="text"
                  id="target_company_url"
                  name="target_company_url"
                  value={formData.target_company_url}
                  onChange={handleChange}
                  placeholder="example.com"
                  className="block w-full pl-10 pr-3 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                  required
                />
              </div>
            </div>

            <div>
              <label htmlFor="attendee_name" className="block text-sm font-medium text-sage-700 mb-1">
                Attendee Full Name
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-sage-400" />
                </div>
                <input
                  type="text"
                  id="attendee_name"
                  name="attendee_name"
                  value={formData.attendee_name}
                  onChange={handleChange}
                  placeholder="John Doe"
                  className="block w-full pl-10 pr-3 py-2 border border-sage-300 rounded-lg focus:ring-2 focus:ring-sage-500 focus:border-sage-500"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-100 text-red-600 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <div className="flex justify-end gap-4">
              <button
                type="button"
                onClick={() => navigate(`/meeting-brief/${id}`)}
                className="px-4 py-2 text-sage-600 hover:text-sage-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="flex items-center gap-2 bg-sage-600 text-white rounded-lg px-6 py-2 hover:bg-sage-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sage-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {saving ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Save Changes'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}