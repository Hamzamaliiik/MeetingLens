export interface MeetingBrief {
  id: string
  user_id: string
  meeting_date: string
  target_company_name: string
  generated_questions: Record<string, any>
  document_url: string
  created_at: string
  target_company_url: string | null
  attendee_name: string | null
  industry: string
  founded_year: string
  location: string
  estimated_revenue: string
  employee_count: number
  socials_url: string
  about: string
  target_company_products: string
  what_we_know: string | null
  attendee_linkedin_url: string
  attendee_title: string
}

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          full_name: string | null
          job_title: string | null
          company_name: string | null
          company_products: string | null
          subscription_status: 'active' | 'canceled' | 'past due' | null
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: Omit<Database['public']['Tables']['users']['Row'], 'id' | 'created_at' | 'updated_at'>
        Update: Partial<Omit<Database['public']['Tables']['users']['Row'], 'id' | 'created_at' | 'updated_at'>>
      }
      meeting_briefs: {
        Row: MeetingBrief
        Insert: Omit<MeetingBrief, 'id' | 'created_at'>
        Update: Partial<Omit<MeetingBrief, 'id' | 'created_at'>>
      }
    }
  }
}